#include<stdio.h>
#include<string.h>
#define SIZEBUFFER 9000
#define NBMOT 5
int main(int argc, char const *argv[])
{
	if(argc != 3)
	{
		fprintf(stderr, "pas le bon argument : progname filesource filedest\n");
		return 1;
	}
	else
	{
		FILE* fichier_s = NULL;
    	fichier_s = fopen(argv[1], "r+");
    	if (fichier_s == NULL)
    	{
    		printf("Impossible de lire le fichier %s", argv[1]);
    		return(1);
    	}
    	FILE* fichier_d = NULL;
    	fichier_d = fopen(argv[2], "w+");
    	if (fichier_d == NULL)
    	{
    		printf("Impossible crréer le fichier %s", argv[2]);
    		return(1);
    	}
    	char buf[SIZEBUFFER];
    	char * token = NULL;
    	char * disagreement [NBMOT] = {"noblesse", "distractions", "mariage", "parlement","gracieux" };
    	char * agrement [NBMOT] = {"mystérieux", "destinée", "manière", "élégant", "révolution" };
    	int fined =0;
    	fprintf(fichier_d, "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
		fprintf(fichier_d, "<?xml-stylesheet href=\"/tel.xsl\" type=\"text/xsl\" ?>\n");
		fprintf(fichier_d, "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n\n\n");


    	while (fgets(buf, SIZEBUFFER , fichier_s) != NULL )
		{
			token = strtok(buf, " ");
			while(token != NULL) 
			{
				if(token[strlen(token)-1] == ',') token[strlen(token)-1] = '\0';
				for (int i = 0; i < NBMOT; ++i)
				{

					if (strcmp(token, disagreement[i]) == 0)
					{
						fputs("<Disagreement int = 2>", fichier_d);
						fputs(token, fichier_d);
						fputs("</Disagreement>", fichier_d);
						fined = 1;
						break;
					}
					else if (strcmp(token, agrement[i]) == 0)
					{
						fputs("<Agrement int = 2>", fichier_d);
						fputs(token, fichier_d);
						fputs("</Agrement>", fichier_d);
						fined = 1;
						break;
					}
					else
					{
						fined = 0;	
					}
				}
				if (!fined)
				{
					fputs(token, fichier_d);
					fputs(" ", fichier_d);
					
				}
				token = strtok(NULL, " ");
			}
    	}
    }
	return 0;
}